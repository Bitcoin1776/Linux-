Sample configuration files for:
```
SystemD: bitcoin1776d.service
Upstart: bitcoin1776d.conf
OpenRC:  bitcoin1776d.openrc
         bitcoin1776d.openrcconf
CentOS:  bitcoin1776d.init
OS X:    org.bitcoin1776.bitcoin1776d.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
