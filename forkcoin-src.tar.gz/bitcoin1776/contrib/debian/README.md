
Debian
====================
This directory contains files used to package bitcoin1776d/bitcoin1776-qt
for Debian-based Linux systems. If you compile bitcoin1776d/bitcoin1776-qt yourself, there are some useful files here.

## bitcoin1776: URI support ##


bitcoin1776-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install bitcoin1776-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your bitcoin1776-qt binary to `/usr/bin`
and the `../../share/pixmaps/bitcoin1776128.png` to `/usr/share/pixmaps`

bitcoin1776-qt.protocol (KDE)

